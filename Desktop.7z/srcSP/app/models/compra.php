<?php  
namespace App\Models;
 
class compra extends \Illuminate\Database\Eloquent\Model{  
    public $timestamps = false;
}
?>
